﻿namespace SWE_TourPlanner_WPF.Models
{
    public enum EDifficulty
    {
        VeryEasy = 0,
        Easy = 1,
        Medium = 2,
        Hard = 3,
        VeryHard = 4
    }
}