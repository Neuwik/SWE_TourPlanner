﻿public enum ERating
{
    ZeroStars = 0,
    OneStars = 1,
    TwoStars = 2,
    ThreeStars = 3,
    FourStars = 4,
    FiveStars = 5
}