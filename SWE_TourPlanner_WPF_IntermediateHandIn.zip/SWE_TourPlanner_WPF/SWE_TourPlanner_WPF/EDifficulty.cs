﻿public enum EDifficulty
{
    easy = 1,
    medium = 3,
    hard = 5
}