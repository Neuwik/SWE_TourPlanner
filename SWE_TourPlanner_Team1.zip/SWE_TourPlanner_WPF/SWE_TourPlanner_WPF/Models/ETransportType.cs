﻿namespace SWE_TourPlanner_WPF.Models
{
    public enum ETransportType
    {
        Car = 0,
        Bike = 1,
        Foot = 2
    }
}