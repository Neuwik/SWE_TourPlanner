﻿using System.Windows.Controls;

namespace SWE_TourPlanner_WPF
{
    /// <summary>
    /// Interaktionslogik für TourInputFields.xaml
    /// </summary>
    public partial class TourInputFields : UserControl
    {
        public TourInputFields()
        {
            InitializeComponent();
        }
    }
}
